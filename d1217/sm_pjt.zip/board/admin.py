from django.contrib import admin
from board.models import Board

admin.site.register(Board)

