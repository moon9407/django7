from django.contrib import admin
from stuscore.models import Stuscore

admin.site.register(Stuscore)