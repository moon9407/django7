from django.contrib import admin
from member.models import Member

admin.site.register(Member)
