from django.contrib import admin
from product.models import Payment,PaymentAmount

admin.site.register(Payment)
admin.site.register(PaymentAmount)
