from django.contrib import admin
from customer.models import Board

admin.site.register(Board)
