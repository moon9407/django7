from django.contrib import admin
from home.models import ChartData


admin.site.register(ChartData)

