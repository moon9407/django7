from django.contrib import admin
from home.models import chartData

admin.site.register(chartData)